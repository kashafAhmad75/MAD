import React, { useState, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Alert } from "react-native";
import { db, auth } from "../firebase";
import { collection, addDoc, getDocs, deleteDoc, doc } from "firebase/firestore";
import { signOut } from "firebase/auth";

export default function MainScreen({ navigation }) {
  const [note, setNote] = useState("");
  const [notes, setNotes] = useState([]);

  const addNote = async () => {
    await addDoc(collection(db, "notes"), { text: note });
    setNote("");
    Alert.alert("Saved", "Note added ✔");
    fetchNotes();
  };

  const fetchNotes = async () => {
    const data = await getDocs(collection(db, "notes"));
    setNotes(data.docs.map(doc => ({ id: doc.id, ...doc.data() })));
  };

  const deleteNote = async (id) => {
    await deleteDoc(doc(db, "notes", id));
    fetchNotes();
  };

  const logout = async () => {
    await signOut(auth);
    navigation.replace("Auth");
  };

  useEffect(() => {
    fetchNotes();
  }, []);

  return (
    <View style={styles.container}>
      
      {/* HEADER */}
      <Text style={styles.title}>My Notes 📒</Text>

      {/* INPUT CARD */}
      <View style={styles.inputCard}>
        <TextInput
          placeholder="Write something..."
          value={note}
          onChangeText={setNote}
        />
      </View>

      <TouchableOpacity style={styles.addBtn} onPress={addNote}>
        <Text style={styles.btnText}>Add Note</Text>
      </TouchableOpacity>

      {/* NOTES */}
      <FlatList
        data={notes}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.noteCard}>
            <Text style={{ flex: 1 }}>{item.text}</Text>
            <TouchableOpacity onPress={() => deleteNote(item.id)}>
              <Text style={{ color: "red" }}>X</Text>
            </TouchableOpacity>
          </View>
        )}
      />

      {/* BUTTONS */}
      <TouchableOpacity style={styles.movieBtn} onPress={() => navigation.navigate("Movies")}>
        <Text style={styles.btnText}>View Movies 🎬</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.logoutBtn} onPress={logout}>
        <Text style={styles.btnText}>Logout</Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#F5F7FB" },

  title: {
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 10,
  },

  inputCard: {
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 12,
    marginBottom: 10,
  },

  addBtn: {
    backgroundColor: "#4C6EF5",
    padding: 12,
    borderRadius: 12,
  },

  noteCard: {
    flexDirection: "row",
    backgroundColor: "#fff",
    padding: 12,
    marginTop: 10,
    borderRadius: 12,
  },

  movieBtn: {
    backgroundColor: "#20C997",
    padding: 12,
    borderRadius: 12,
    marginTop: 20,
  },

  logoutBtn: {
    backgroundColor: "#FF6B6B",
    padding: 12,
    borderRadius: 12,
    marginTop: 10,
  },

  btnText: {
    color: "#fff",
    textAlign: "center",
    fontWeight: "bold",
  },
});