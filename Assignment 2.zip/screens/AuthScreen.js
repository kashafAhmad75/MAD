import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "firebase/auth";

import { auth } from "../firebase";

export default function AuthScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // 🔥 SIGNUP
  const signup = async () => {
    try {
      if (!email || !password) {
        Alert.alert("Error", "Please fill all fields");
        return;
      }

      if (password.length < 6) {
        Alert.alert("Error", "Password must be at least 6 characters");
        return;
      }

      await createUserWithEmailAndPassword(auth, email.trim(), password);

      Alert.alert("Success", "Account created successfully ✅");

      // ✅ CLEAR FIELDS AFTER SIGNUP
      setEmail("");
      setPassword("");

    } catch (e) {
      Alert.alert("Signup Failed", e.message);

      // ✅ OPTIONAL: also clear on error
      setEmail("");
      setPassword("");
    }
  };

  // 🔥 LOGIN
  const login = async () => {
    try {
      if (!email || !password) {
        Alert.alert("Error", "Please fill all fields");
        return;
      }

      await signInWithEmailAndPassword(auth, email.trim(), password);

      // ✅ CLEAR FIELDS AFTER LOGIN
      setEmail("");
      setPassword("");

      navigation.replace("Main");

    } catch (e) {
      Alert.alert("Login Failed", e.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logo}>📝 Notes App</Text>
      <Text style={styles.subtitle}>Login or Create Account</Text>

      <View style={styles.card}>
        <TextInput
          placeholder="Email"
          value={email}               // ✅ important for clearing
          onChangeText={setEmail}
          style={styles.input}
        />

        <TextInput
          placeholder="Password"
          secureTextEntry
          value={password}           // ✅ important for clearing
          onChangeText={setPassword}
          style={styles.input}
        />

        <TouchableOpacity style={styles.loginBtn} onPress={login}>
          <Text style={styles.btnText}>Login</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.signupBtn} onPress={signup}>
          <Text style={styles.btnText}>Create Account</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#4C6EF5",
    justifyContent: "center",
    padding: 20,
  },

  logo: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#fff",
    textAlign: "center",
  },

  subtitle: {
    textAlign: "center",
    color: "#E5E5E5",
    marginBottom: 20,
  },

  card: {
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 20,
  },

  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 12,
    borderRadius: 10,
    marginBottom: 10,
  },

  loginBtn: {
    backgroundColor: "#4C6EF5",
    padding: 12,
    borderRadius: 10,
    marginTop: 10,
  },

  signupBtn: {
    backgroundColor: "#20C997",
    padding: 12,
    borderRadius: 10,
    marginTop: 10,
  },

  btnText: {
    color: "#fff",
    textAlign: "center",
    fontWeight: "bold",
  },
});