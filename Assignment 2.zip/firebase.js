import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Firebase config (YOU already have this correct)
const firebaseConfig = {
  apiKey: "AIzaSyC786gPJDMWnTt2BEjTA8FuC-bxyxTwAYo",
  authDomain: "newassignment-b5613.firebaseapp.com",
  projectId: "newassignment-b5613",
  storageBucket: "newassignment-b5613.firebasestorage.app",
  messagingSenderId: "476877683212",
  appId: "1:476877683212:web:b23791e192166717708c29"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// 🔥 EXPORT THESE (THIS IS WHAT YOU WERE MISSING)
export const auth = getAuth(app);
export const db = getFirestore(app);