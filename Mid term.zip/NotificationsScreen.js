import React, { useContext } from 'react';
import { View, Text, FlatList, TouchableOpacity, ImageBackground } from 'react-native';
import { AppContext } from '../context/AppContext';
import { MaterialIcons } from '@expo/vector-icons';
import { getStyles } from '../styles/GlobalStyles';

const notifications = [
  { id: '1', title: 'New assignment uploaded', time: '2h ago' },
  { id: '2', title: 'Class canceled', time: '5h ago' },
  { id: '3', title: 'Result published', time: '1d ago' },
];

export default function NotificationsScreen() {
  const { theme } = useContext(AppContext);
  const styles = getStyles(theme);

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.courseCard, { backgroundColor: theme.card }]}
      onPress={() => alert(item.title)}
    >
      <MaterialIcons name="notifications" size={32} color={theme.primary} />
      <View style={{ marginLeft: 15 }}>
        <Text style={[styles.courseTitle, { color: theme.text }]}>{item.title}</Text>
        <Text style={[styles.courseSubtitle, { color: theme.text }]}>{item.time}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <ImageBackground
      source={require('../assets/background.jpg')}
      style={{ flex: 1, width: '100%', height: '100%' }}
      resizeMode="cover"
    >
      <FlatList
        data={notifications}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={{ padding: 20 }}
      />
    </ImageBackground>
  );
}