import React, { useState, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity, ImageBackground, ScrollView, Alert } from 'react-native';
import { AppContext } from '../context/AppContext';
import { getStyles } from '../styles/GlobalStyles';

export default function EditProfileScreen({ navigation }) {
  const { student, updateStudent, theme } = useContext(AppContext);
  const styles = getStyles(theme);

  const [name, setName] = useState(student?.name || '');
  const [email, setEmail] = useState(student?.email || '');
  const [semester, setSemester] = useState(student?.semester || '');
  const [gpa, setGpa] = useState(student?.gpa || '');
  const [cgpa, setCgpa] = useState(student?.cgpa || '');

  const handleSave = async () => {
    if (!name || !email || !semester || !gpa || !cgpa) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    const updatedData = { ...student, name, email, semester, gpa, cgpa };

    try {
      await updateStudent(updatedData); // Save to context + AsyncStorage
      Alert.alert('Success', 'Profile updated successfully');
      navigation.goBack();
    } catch (error) {
      Alert.alert('Error', 'Could not save profile');
      console.log(error);
    }
  };

  return (
    <ImageBackground
      source={require('../assets/background.jpg')}
      style={{ flex: 1, width: '100%', height: '100%' }}
      resizeMode="cover"
    >
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <TextInput
          style={styles.input}
          value={name}
          onChangeText={setName}
          placeholder="Name"
          placeholderTextColor={theme.placeholder}
        />
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          placeholder="Email"
          placeholderTextColor={theme.placeholder}
        />
        <TextInput
          style={styles.input}
          value={semester}
          onChangeText={setSemester}
          placeholder="Semester"
          placeholderTextColor={theme.placeholder}
        />
        <TextInput
          style={styles.input}
          value={gpa}
          onChangeText={setGpa}
          placeholder="GPA"
          placeholderTextColor={theme.placeholder}
          keyboardType="numeric"
        />
        <TextInput
          style={styles.input}
          value={cgpa}
          onChangeText={setCgpa}
          placeholder="CGPA"
          placeholderTextColor={theme.placeholder}
          keyboardType="numeric"
        />

        <TouchableOpacity style={styles.button} onPress={handleSave}>
          <Text style={styles.buttonText}>Save</Text>
        </TouchableOpacity>
      </ScrollView>
    </ImageBackground>
  );
}