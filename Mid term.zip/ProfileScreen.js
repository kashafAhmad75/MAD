import React, { useContext } from 'react';
import { View, Text, Image, TouchableOpacity, ImageBackground, StyleSheet } from 'react-native';
import { AppContext } from '../context/AppContext';
import { MaterialIcons } from '@expo/vector-icons';

export default function ProfileScreen({ navigation }) {
  const { student, theme } = useContext(AppContext);

  return (
    <ImageBackground
      source={require('../assets/background.jpg')}
       style={{ flex: 1, width: '100%', height: '100%' }}
      resizeMode="cover"
    >
      <View style={[styles.profileCard, { backgroundColor: theme.card }]}>
        <Image
          source={require('../assets/logo.png')}
          style={{ width: 100, height: 100, borderRadius: 50, marginBottom: 10 }}
        />
        <Text style={[styles.name, { color: theme.text }]}>{student?.name}</Text>
        <Text style={[styles.info, { color: theme.text }]}>SAP ID: {student?.sapId}</Text>
        <Text style={[styles.info, { color: theme.text }]}>Semester: {student?.semester}</Text>
        <Text style={[styles.info, { color: theme.text }]}>GPA: {student?.gpa || '-'}</Text>
      </View>

      <TouchableOpacity
        style={[styles.button, { backgroundColor: theme.primary }]}
        onPress={() => navigation.navigate('EditProfile')}
      >
        <MaterialIcons name="edit" size={24} color="#fff" />
        <Text style={styles.buttonText}>Edit Profile</Text>
      </TouchableOpacity>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  profileCard: { borderRadius: 20, padding: 20, alignItems: 'center', marginBottom: 20, elevation: 4 },
  name: { fontSize: 24, fontWeight: 'bold', marginBottom: 5 },
  info: { fontSize: 16, marginBottom: 3 },
  button: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', padding: 15, borderRadius: 12 },
  buttonText: { color: '#fff', fontWeight: 'bold', fontSize: 16, marginLeft: 8 },
});