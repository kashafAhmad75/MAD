import React, { useContext } from 'react';
import { View, Text, TouchableOpacity, ScrollView, ImageBackground } from 'react-native';
import { AppContext } from '../context/AppContext';
import { getStyles } from '../styles/GlobalStyles';
import { MaterialIcons } from '@expo/vector-icons';

export default function HomeScreen({ navigation }) {
  const { student, theme } = useContext(AppContext);
  const styles = getStyles(theme);

  const infoCards = [
    { label: 'SAP ID', value: student?.sapId, icon: 'badge' },
    { label: 'Semester', value: student?.semester, icon: 'school' },
    { label: 'GPA', value: student?.gpa, icon: 'star' },
    { label: 'CGPA', value: student?.cgpa, icon: 'stars' },
  ];

  const menuCards = [
    { label: 'Courses', icon: 'menu-book', action: () => navigation.navigate('Courses') },
    { label: 'Assignments', icon: 'assignment', action: () => navigation.navigate('Assignments') },
    { label: 'Notifications', icon: 'notifications', action: () => navigation.navigate('Notifications') },
  ];

  return (
    <ImageBackground
      source={require('../assets/background.jpg')}
      style={{ flex: 1, width: '100%', height: '100%' }}
      resizeMode="cover"
    >
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        {/* Greeting */}
        <Text style={[styles.heading, { color: '#000000', marginBottom: 20 }]}>
          Hello {student?.name}
        </Text>

        {/* Student Info Cards */}
        {infoCards.map((card, idx) => (
          <View
            key={idx}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: theme.card,
              padding: 15,
              borderRadius: 15,
              marginBottom: 15,
              elevation: 4,
            }}
          >
            <MaterialIcons name={card.icon} size={30} color={theme.primary} />
            <View style={{ marginLeft: 15 }}>
              <Text style={[styles.courseTitle, { color: theme.text }]}>{card.label}</Text>
              <Text style={[styles.courseSubtitle, { color: theme.text }]}>{card.value}</Text>
            </View>
          </View>
        ))}

        {/* Menu Cards */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 }}>
          {menuCards.map((card, idx) => (
            <TouchableOpacity
              key={idx}
              style={{
                backgroundColor: theme.card,
                width: '30%',
                padding: 15,
                borderRadius: 15,
                alignItems: 'center',
              }}
              onPress={card.action} // Navigation added here
            >
              <MaterialIcons name={card.icon} size={36} color={theme.primary} />
              <Text style={[styles.menuText, { marginTop: 10 }]}>{card.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </ImageBackground>
  );
}