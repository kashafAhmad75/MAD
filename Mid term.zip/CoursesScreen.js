import React, { useContext } from 'react';
import { View, Text, FlatList, TouchableOpacity, ImageBackground, StyleSheet } from 'react-native';
import { AppContext } from '../context/AppContext';
import { MaterialCommunityIcons } from '@expo/vector-icons';

const courseData = [
  { id: '1', title: 'Mathematics', subtitle: 'Algebra & Calculus', icon: 'function-variant' },
  { id: '2', title: 'Physics', subtitle: 'Mechanics & Optics', icon: 'atom' },
  { id: '3', title: 'Computer Science', subtitle: 'Java, Web Dev', icon: 'laptop' },
  { id: '4', title: 'English', subtitle: 'Composition & Grammar', icon: 'book-open-page-variant' },
  { id: '5', title: 'Chemistry', subtitle: 'Organic & Inorganic', icon: 'flask' },
  { id: '6', title: 'Biology', subtitle: 'Zoology & Botany', icon: 'dna' },
  { id: '7', title: 'History', subtitle: 'World & Pakistan', icon: 'history' },
];

export default function CoursesScreen() {
  const { theme } = useContext(AppContext);

  const renderItem = ({ item }) => (
    <TouchableOpacity style={[styles.courseCard, { backgroundColor: theme.card }]} onPress={() => alert(`Clicked ${item.title}`)}>
      <MaterialCommunityIcons name={item.icon} size={30} color={theme.primary} />
      <View style={{ marginLeft: 15 }}>
        <Text style={[styles.courseTitle, { color: theme.text }]}>{item.title}</Text>
        <Text style={[styles.courseSubtitle, { color: theme.text }]}>{item.subtitle}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <ImageBackground source={require('../assets/background.jpg')} 
     style={{ flex: 1, width: '100%', height: '100%' }}
      resizeMode="cover">
      <FlatList
        data={courseData}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={{ padding: 20 }}
      />
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  courseCard: { flexDirection: 'row', padding: 20, borderRadius: 15, marginBottom: 15, alignItems: 'center', elevation: 4 },
  courseTitle: { fontSize: 18, fontWeight: 'bold' },
  courseSubtitle: { fontSize: 14, marginTop: 4 },
});