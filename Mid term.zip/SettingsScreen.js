import React, { useContext, useState } from 'react';
import { View, Text, TouchableOpacity, Switch, ImageBackground } from 'react-native';
import { AppContext } from '../context/AppContext';
import { getStyles } from '../styles/GlobalStyles';
import { MaterialIcons } from '@expo/vector-icons';

export default function SettingsScreen() {
  const { theme, toggleTheme, logout, student } = useContext(AppContext);
  const styles = getStyles(theme);

  // Example additional setting
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const handleLogout = () => {
    logout();
  };

  return (
    <ImageBackground
      source={require('../assets/background.jpg')}
      style={{ flex: 1, width: '100%', height: '100%' }}
      resizeMode="cover"
    >
      <View style={{ padding: 20 }}>
        <Text style={[styles.heading, { color: '#000000', marginBottom: 20 }]}>
          Settings
        </Text>

        {/* Profile Card */}
        <View
          style={{
            backgroundColor: theme.card,
            borderRadius: 20,
            padding: 20,
            marginBottom: 20,
            flexDirection: 'row',
            alignItems: 'center',
            elevation: 4,
          }}
        >
          <MaterialIcons name="person" size={50} color={theme.primary} />
          <View style={{ marginLeft: 15 }}>
            <Text style={[styles.courseTitle, { color: theme.text, fontSize: 18 }]}>
              {student?.name}
            </Text>
            <Text style={[styles.courseSubtitle, { color: theme.text }]}>
              {student?.email}
            </Text>
          </View>
          <TouchableOpacity
            onPress={() => alert('Edit Profile coming soon!')}
            style={{ marginLeft: 'auto' }}
          >
            <MaterialIcons name="edit" size={24} color={theme.primary} />
          </TouchableOpacity>
        </View>

        {/* Dark Mode Toggle */}
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            backgroundColor: theme.card,
            borderRadius: 15,
            padding: 15,
            marginBottom: 15,
            elevation: 2,
          }}
        >
          <Text style={[styles.text, { fontWeight: 'bold', fontSize: 16 }]}>
            Dark Mode
          </Text>
          <Switch
            value={theme.dark}
            onValueChange={toggleTheme}
            trackColor={{ false: '#767577', true: theme.primary }}
            thumbColor="#fff"
          />
        </View>

        {/* Notifications Toggle */}
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            backgroundColor: theme.card,
            borderRadius: 15,
            padding: 15,
            marginBottom: 15,
            elevation: 2,
          }}
        >
          <Text style={[styles.text, { fontWeight: 'bold', fontSize: 16 }]}>
            Notifications
          </Text>
          <Switch
            value={notificationsEnabled}
            onValueChange={setNotificationsEnabled}
            trackColor={{ false: '#767577', true: theme.primary }}
            thumbColor="#fff"
          />
        </View>

        {/* App Info Card */}
        <View
          style={{
            backgroundColor: theme.card,
            borderRadius: 15,
            padding: 15,
            marginBottom: 15,
            elevation: 2,
          }}
        >
          <Text style={[styles.courseTitle, { color: theme.text, fontSize: 16 }]}>
            App Version
          </Text>
          <Text style={[styles.courseSubtitle, { color: theme.text }]}>1.0.0</Text>
        </View>

        {/* Logout Button */}
        <TouchableOpacity
          style={{
            backgroundColor: '#4CAF50',
            padding: 15,
            borderRadius: 15,
            alignItems: 'center',
            marginTop: 10,
          }}
          onPress={handleLogout}
        >
          <Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16 }}>
            Logout
          </Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}