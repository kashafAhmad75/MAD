import React, { useContext } from 'react';
import { View, Text, FlatList, TouchableOpacity, ImageBackground } from 'react-native';
import { AppContext } from '../context/AppContext';
import { MaterialIcons } from '@expo/vector-icons';
import { getStyles } from '../styles/GlobalStyles';

const assignments = [
  { id: '1', title: 'Math Assignment 1', due: '2026-04-15' },
  { id: '2', title: 'Physics Lab Report', due: '2026-04-16' },
  { id: '3', title: 'CS Project', due: '2026-04-20' },
];

export default function AssignmentsScreen() {
  const { theme } = useContext(AppContext);
  const styles = getStyles(theme);

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.courseCard, { backgroundColor: theme.card }]}
      onPress={() => alert(`Open ${item.title}`)}
    >
      <MaterialIcons name="assignment" size={32} color={theme.primary} />
      <View style={{ marginLeft: 15 }}>
        <Text style={[styles.courseTitle, { color: theme.text }]}>{item.title}</Text>
        <Text style={[styles.courseSubtitle, { color: theme.text }]}>Due: {item.due}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <ImageBackground
      source={require('../assets/background.jpg')}
      style={{ flex: 1, width: '100%', height: '100%' }}
      resizeMode="cover"
    >
      <FlatList
        data={assignments}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={{ padding: 20 }}
      />
    </ImageBackground>
  );
}