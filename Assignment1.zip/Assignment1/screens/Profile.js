import React, { useState } from 'react';
import { View, Text, Image, TextInput, StyleSheet } from 'react-native';
import styles from '../styles';

export default function Profile() {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');

  return (
    <View style={[styles.container, localStyles.background]}>

      <View style={localStyles.card}>
        
        <Image
          source={{ uri: 'https://randomuser.me/api/portraits/women/65.jpg' }}
          style={localStyles.profileImage}
        />

        <Text style={localStyles.heading}>My Profile</Text>

        <TextInput
          style={[styles.input, localStyles.input]}
          placeholder="Enter Name"
          placeholderTextColor="#888"
          value={name}
          onChangeText={setName}
        />

        <TextInput
          style={[styles.input, localStyles.input]}
          placeholder="Enter Age"
          placeholderTextColor="#888"
          value={age}
          onChangeText={setAge}
          keyboardType="numeric"
        />

        <View style={localStyles.outputBox}>
          <Text style={localStyles.outputText}>Name: {name}</Text>
          <Text style={localStyles.outputText}>Age: {age}</Text>
        </View>

      </View>
    </View>
  );
}

const localStyles = StyleSheet.create({
  background: {
    backgroundColor: '#E3F2FD',  // light blue background
  },
  card: {
    width: '90%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 15,
    alignItems: 'center',
    elevation: 6, // shadow for Android
  },
  profileImage: {
    width: 130,
    height: 130,
    borderRadius: 65,
    borderWidth: 4,
    borderColor: '#4CAF50',
    marginBottom: 15,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  input: {
    backgroundColor: '#F5F5F5',
    borderColor: '#4CAF50',
    borderWidth: 1,
  },
  outputBox: {
    marginTop: 20,
    backgroundColor: '#E8F5E9',
    padding: 15,
    borderRadius: 10,
    width: '100%',
  },
  outputText: {
    fontSize: 18,
    color: '#2E7D32',
    fontWeight: '600',
  },
});