import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text, Alert, StyleSheet } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import styles from '../styles';

export default function Contact() {
  const [email, setEmail] = useState('');

  const handleSubmit = () => {
    if (email === '') {
      Alert.alert('Error', 'Please enter your email');
    } else {
      Alert.alert('Submitted ✅', `Your email is: ${email}`);
    }
  };

  return (
    <View style={[styles.container, localStyles.background]}>
      
      <View style={localStyles.card}>

        <Text style={localStyles.heading}>📩 Contact Us</Text>

        <View style={localStyles.inputContainer}>
          <MaterialIcons 
            name="email" 
            size={24} 
            color="#1976D2" 
            style={{ marginRight: 10 }} 
          />
          <TextInput
            style={localStyles.input}
            placeholder="Enter your email"
            placeholderTextColor="#888"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
          />
        </View>

        <TouchableOpacity style={localStyles.button} onPress={handleSubmit}>
          <Text style={localStyles.buttonText}>Submit</Text>
        </TouchableOpacity>

      </View>

    </View>
  );
}

const localStyles = StyleSheet.create({
  background: {
    backgroundColor: '#E3F2FD', // Light blue background
  },
  card: {
    width: '90%',
    backgroundColor: '#FFFFFF',
    padding: 25,
    borderRadius: 20,
    elevation: 8,
    alignItems: 'center',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1565C0',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F8FF',
    borderWidth: 1,
    borderColor: '#90CAF9',
    borderRadius: 10,
    paddingHorizontal: 10,
    width: '100%',
    marginBottom: 20,
  },
  input: {
    flex: 1,
    height: 45,
    fontSize: 16,
  },
  button: {
    backgroundColor: '#1976D2',
    paddingVertical: 12,
    paddingHorizontal: 40,
    borderRadius: 10,
    elevation: 4,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});