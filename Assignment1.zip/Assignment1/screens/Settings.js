import React, { useState } from 'react';
import { View, Text, Switch, StyleSheet } from 'react-native';
import styles from '../styles';

export default function Settings() {
  const [isDark, setIsDark] = useState(false);

  return (
    <View
      style={[
        styles.container,
        localStyles.container,
        { backgroundColor: isDark ? '#121212' : '#E3F2FD' }
      ]}
    >
      <View
        style={[
          localStyles.card,
          { backgroundColor: isDark ? '#1E1E1E' : '#FFFFFF' }
        ]}
      >
        <Text
          style={[
            styles.title,
            localStyles.title,
            { color: isDark ? '#12f037' : '#08f5cd' }
          ]}
        >
          ⚙ Settings
        </Text>

        <Text
          style={[
            localStyles.modeText,
            { color: isDark ? '#FFFFFF' : '#333333' }
          ]}
        >
          {isDark ? 'Dark Mode is ON 🌙' : 'Light Mode is ON ☀'}
        </Text>

        <Switch
          value={isDark}
          onValueChange={setIsDark}
          trackColor={{ false: '#81D4FA', true: '#FFD54F' }}
          thumbColor={isDark ? '#FFB300' : '#0288D1'}
        />
      </View>
    </View>
  );
}

const localStyles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    width: '85%',
    padding: 30,
    borderRadius: 20,
    alignItems: 'center',
    elevation: 8,
  },
  title: {
    marginBottom: 20,
    fontSize: 26,
  },
  modeText: {
    fontSize: 18,
    marginBottom: 20,
    fontWeight: '500',
  },
});