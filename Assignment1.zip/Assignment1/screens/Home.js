import React from 'react';
import { View, Text, ImageBackground, TouchableOpacity, StyleSheet } from 'react-native';
import styles from '../styles';

export default function Home({ navigation }) {
  return (
    <ImageBackground
      source={{  uri: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1000' }}
      style={localStyles.background}
      resizeMode="cover"
    >
      <View style={localStyles.overlay}>
        
        <Text style={[styles.title, localStyles.title]}>
          🎓 Student App
        </Text>

        <TouchableOpacity
          style={[styles.button, localStyles.button]}
          onPress={() => navigation.navigate('Profile')}
        >
          <Text style={styles.buttonText}>Profile</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, localStyles.button]}
          onPress={() => navigation.navigate('Settings')}
        >
          <Text style={styles.buttonText}>Settings</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, localStyles.button]}
          onPress={() => navigation.navigate('Contact')}
        >
          <Text style={styles.buttonText}>Contact</Text>
        </TouchableOpacity>

      </View>
    </ImageBackground>
  );
}

const localStyles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',   // Dark overlay for better text visibility
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    color: '#fff',
    fontSize: 32,
    marginBottom: 40,
    textShadowColor: '#000',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 5,
  },
  button: {
    width: '70%',
    backgroundColor: '#5111ff',
    padding: 15,
    borderRadius: 10,
    marginVertical: 10,
    elevation: 5, // Shadow for Android
  },
});